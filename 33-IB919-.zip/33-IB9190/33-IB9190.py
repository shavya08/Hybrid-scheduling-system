# -*- coding: utf-8 -*-
"""
Created on Tue Mar  5 02:26:30 2024

AAMA group assignment

@author: Group 33
"""

# Import gurobipy package
import gurobipy as gp
from gurobipy import GRB
# Import pandas package
import pandas as pd
# Import numpy package
import numpy as np

file_name = "33-IB9190.xlsx"
df = pd.read_excel(file_name, index_col = 0)

# Import student&class data
student_class = df.iloc[1:230, :]
df_student_class = student_class.to_numpy()

# Import time&class data
time_class = df.iloc[233:323, 0:]
df_time_class = time_class.to_numpy()

# Import the number of students enrolled in class k
Ak_class = df.iloc[325]
Ak = Ak_class.to_numpy()

# Import the room capacity of class k
room_cap = df.iloc[327]
Rk = room_cap.to_numpy()

# Set a new social distance capacity for class k
Ck = Rk * 0.5
Ck = Ck.astype(int)


# Initialize the Gurobi model
m = gp.Model()

# Set parameters
M = 3
E = 20
lam = 0.25
mu = 0.1

# Define range of indices
students = range(len(df_student_class))
classes = range(len(Ak))
groups = range(M)
hours = range(len(df_time_class))

# Set decision variable
x = m.addVars(students,groups, vtype=GRB.BINARY)

# Set auxiliary variables
e = m.addVars(groups, classes, vtype=GRB.CONTINUOUS, lb=0)
fi = m.addVars(groups, classes, vtype=GRB.CONTINUOUS, lb=0)
s = m.addVar(vtype=GRB.INTEGER, lb=0)
sj = m.addVars(groups, hours, vtype=GRB.INTEGER, lb=0)

# Set objective functiion
obj = gp.quicksum(e[j, k] for j in groups for k in classes) + lam * gp.quicksum(fi[j, k] for j in groups for k in classes) + mu * s
m.setObjective(obj, GRB.MINIMIZE)

# Set constraints
# Rule 1: Each student can be assigned to only one group
for i in students:
        m.addConstr(gp.quicksum(x[i,j] for j in groups) == 1)

# Rule 2: Total Excess Constraint        
for j in groups:
    for k in classes:
            m.addConstr(gp.quicksum(x[i,j] for i in students if df_student_class[i, k] == 1) - Ck[k] <= e[j, k])

# Rule 3: Total Deviation Constraint            
for j in groups:
    for k in classes:
            m.addConstr(gp.quicksum(x[i,j] for i in students if df_student_class[i, k] == 1) - Ak[k]/M <= fi[j, k])
            
for j in groups:
    for k in classes:
            m.addConstr(Ak[k]/M - gp.quicksum(x[i,j] for i in students if df_student_class[i, k] == 1) <= fi[j, k])  

# Rule 4: SSE            
for t in hours:
    for j in groups:
        m.addConstr(sj[j, t] - E <= s)

# Rule 5: SE        
for t in hours:
    for j in groups:
        m.addConstr(gp.quicksum(e[j, k] for k in classes if df_time_class[t, k] == 1) <= sj[j,t])


# Solve model        
m.optimize()


# Get objective value
if m.status == GRB.OPTIMAL:
    print(f"Objective value: {m.objVal}")
else:
    print("Optimal solution not found.")


# Get the value of s
if m.status == GRB.OPTIMAL:
    s_value = s.x
# Print the values of SSE
    print(f"Optimal value for SSE: {s_value}")


# Get the values of fi
if m.status == GRB.OPTIMAL:
    fi_values = {(j, k): fi[j, k].x for j in groups for k in classes}
# Print the values of fi
    for j in groups:
        for k in classes:
            print(f"Optimal value for fi[{j},{k}]: {fi_values[j, k]}")

# Get the values of TD
fi_sum = sum(fi[j, k].x for j in groups for k in classes)
# Print the values of TD
print(f"Optimal value for TD: {fi_sum}")


# Get the values of e            
if m.status == GRB.OPTIMAL:
    e_values = {(j, k): e[j, k].x for j in groups for k in classes}
# Print the values of e
    for j in groups:
        for k in classes:
            print(f"Optimal value for e[{j},{k}]: {e_values[j, k]}")

# Get the values of TE
e_sum = sum(e[j, k].x for j in groups for k in classes)
# Print the values of TE
print(f"Optimal value for TE: {e_sum}")
